```python
#Step 1. Import all important required Libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
#Step 2: Access file data from the document
# Sample data
data = {
    'Regions': [
        'South Mumbai', 'Western Suburbs', 
        'Central Mumbai', 'Navi Mumbai', 
        'Thane', 'Eastern Suburbs'
    ],
    'Price': [
        35000000, 18000000, 
        22000000, 8500000, 
        7000000, 12000000
    ],
    'Size (sq. ft.)': [1200, 1000, 900, 800, 750, 850],
    'Bedrooms': [3, 2, 2, 1, 1, 2],
    'Property Type': ['Apartment', 'Apartment', 'Apartment', 'Apartment', 'Villa', 'Apartment'],
    'Units Sold': [150, 200, 180, 300, 250, 220]
}
```


```python
# Create DataFrame
mumbai_data = pd.DataFrame(data)
print(mumbai_data)
```

               Regions     Price  Size (sq. ft.)  Bedrooms Property Type  \
    0     South Mumbai  35000000            1200         3     Apartment   
    1  Western Suburbs  18000000            1000         2     Apartment   
    2   Central Mumbai  22000000             900         2     Apartment   
    3      Navi Mumbai   8500000             800         1     Apartment   
    4            Thane   7000000             750         1         Villa   
    5  Eastern Suburbs  12000000             850         2     Apartment   
    
       Units Sold  
    0         150  
    1         200  
    2         180  
    3         300  
    4         250  
    5         220  
    


```python
print("\nDataset Info: ")
mumbai_data.info()
```

    
    Dataset Info: 
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 6 entries, 0 to 5
    Data columns (total 6 columns):
     #   Column          Non-Null Count  Dtype 
    ---  ------          --------------  ----- 
     0   Regions         6 non-null      object
     1   Price           6 non-null      int64 
     2   Size (sq. ft.)  6 non-null      int64 
     3   Bedrooms        6 non-null      int64 
     4   Property Type   6 non-null      object
     5   Units Sold      6 non-null      int64 
    dtypes: int64(4), object(2)
    memory usage: 420.0+ bytes
    


```python
print("Dataset Summary: ")
print(mumbai_data.describe())
```

    Dataset Summary: 
                  Price  Size (sq. ft.)  Bedrooms  Units Sold
    count  6.000000e+00        6.000000  6.000000    6.000000
    mean   1.708333e+07      916.666667  1.833333  216.666667
    std    1.046144e+07      163.299316  0.752773   53.166405
    min    7.000000e+06      750.000000  1.000000  150.000000
    25%    9.375000e+06      812.500000  1.250000  185.000000
    50%    1.500000e+07      875.000000  2.000000  210.000000
    75%    2.100000e+07      975.000000  2.000000  242.500000
    max    3.500000e+07     1200.000000  3.000000  300.000000
    


```python
#Find number of missing values in each column
print("Missing Values in Each Columns: ")
print(mumbai_data.isnull().sum())
```

    Missing Values in Each Columns: 
    Regions           0
    Price             0
    Size (sq. ft.)    0
    Bedrooms          0
    Property Type     0
    Units Sold        0
    dtype: int64
    

## Visualisation 1: Average Price of Flats at different regions of Mumbai


```python
plt.figure(figsize=(8,5))
sns.barplot(data = mumbai_data, x='Regions', y='Price', color='cyan')
plt.title("Flat Price Range in Different Regions of Mumbai")
plt.xlabel("Region")
plt.ylabel("Price Range  in Crores(₹)")
plt.xticks(rotation=45)
plt.show()
```


    
![png](output_7_0.png)
    


## Visualisation 2: Box Plot for Price Distribution


```python
plt.figure(figsize=(10,7))
sns.boxplot(data=mumbai_data, x='Regions', hue= 'Regions', y='Price', palette='coolwarm')
plt.title("Price Distribution by Region")
plt.show()
```


    
![png](output_9_0.png)
    


## Visualisation 3: Line Graph for Units Sold vs Property Type


```python
plt.figure(figsize=(8,5))
sns.lineplot(data=mumbai_data, x='Property Type', y = 'Units Sold', marker = 'o', color='coral')
plt.title("Unit Sold by Property Type")
plt.xlabel("Property Type")
plt.ylabel("Units Sold")
plt.grid(True, linestyle = '--', alpha = 0.6)

plt.show()
```


    
![png](output_11_0.png)
    


## Visualisation 4: Pie Chart for Distribution of Size Across Mumbai Regions


```python
plt.figure(figsize=(8, 8))
sizes = mumbai_data.groupby('Regions')['Size (sq. ft.)'].sum()
sizes.plot(kind='pie', autopct='%1.1f%%', startangle=90, colors=sns.color_palette('pastel'))
plt.title("Distribution of Size (sq. ft.) Across Mumbai Regions")
plt.ylabel("")  # Remove default y-label
plt.show()
```


    
![png](output_13_0.png)
    


## Visualisation 5: Scatter Plot to Compare Price (₹) and Size (sq. ft.)


```python
plt.figure(figsize=(8, 5))
sns.scatterplot(data=mumbai_data, x='Size (sq. ft.)', y='Price', hue='Regions', palette='viridis', s=100)
plt.title("Price vs Size (sq. ft.) Across Mumbai Regions")
plt.xlabel("Size (sq. ft.)")
plt.ylabel("Price (₹)")
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend(title='Regions', bbox_to_anchor=(1.05, 1), loc='upper left')  # Move legend outside
plt.show()
```


    
![png](output_15_0.png)
    


## Visualisation 6: Heatmap to visualise relationship b/w Price (₹) and Size (sq. ft.)


```python
# Create a pivot table for the heatmap
heatmap_data = mumbai_data.pivot_table(values='Price', index='Regions', columns='Size (sq. ft.)', aggfunc='mean')

# Plot the heatmap
plt.figure(figsize=(10, 6))
sns.heatmap(heatmap_data, annot=True, fmt='.2f', cmap='coolwarm', cbar=True)
plt.title("Heatmap of Price vs Size (sq. ft.) Across Mumbai Regions")
plt.xlabel("Size (sq. ft.)")
plt.ylabel("Regions")
plt.show()
```


    
![png](output_17_0.png)
    



```python

```
